package com.myfavoritestory.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

interface AuthProvider { suspend fun signInWithGoogle(): User; suspend fun signInWithPhone(phone:String): User; suspend fun signInWithEmail(email:String,password:String): User }
interface BackendRepository { suspend fun sync(state:AppState); suspend fun fetch():AppState? }
interface StorageProvider { suspend fun uploadImage(bytes:ByteArray, path:String):String }

class LocalRepository(context: Context) : BackendRepository, AuthProvider, StorageProvider {
    private val prefs = context.getSharedPreferences("mfs_local", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    fun addWatchEntry(entry:WatchEntry){ _state.value=_state.value.copy(watchEntries=_state.value.watchEntries+entry); persist() }
    fun toggleSavedMovie(id:String){ val s=_state.value.savedMovieIds.toMutableSet(); if(!s.add(id))s.remove(id); _state.value=_state.value.copy(savedMovieIds=s); persist() }
    fun toggleSavedPost(id:String){ val s=_state.value.savedPostIds.toMutableSet(); if(!s.add(id))s.remove(id); _state.value=_state.value.copy(savedPostIds=s); persist() }
    fun addPost(text:String,kind:String="post"){ val p=Post("p"+System.currentTimeMillis(),_state.value.currentUser.id,text,"Ahora",kind); _state.value=_state.value.copy(posts=listOf(p)+_state.value.posts); persist() }
    fun follow(id:String){ val s=_state.value.followingIds.toMutableSet(); if(!s.add(id))s.remove(id); _state.value=_state.value.copy(followingIds=s); persist() }
    fun markRead(){ _state.value=_state.value.copy(notifications=_state.value.notifications.map{it.copy(unread=false)}); persist() }
    fun setPrivacy(key:String,value:Boolean){ _state.value=_state.value.copy(privacy=_state.value.privacy+ (key to value)); persist() }
    override suspend fun sync(state:AppState) { _state.value=state; persist() }
    override suspend fun fetch():AppState = _state.value
    override suspend fun signInWithGoogle():User = _state.value.currentUser
    override suspend fun signInWithPhone(phone:String):User = _state.value.currentUser
    override suspend fun signInWithEmail(email:String,password:String):User = _state.value.currentUser
    override suspend fun uploadImage(bytes:ByteArray,path:String):String = "pending://storage/$path"

    private fun persist(){
        val st=_state.value
        val o=JSONObject()
        o.put("watch", JSONArray(st.watchEntries.map { w -> JSONObject().apply { put("id",w.id);put("movieId",w.movieId);put("date",w.date);put("review",w.review);put("opinion",w.opinion);put("season",w.season ?: -1);put("episode",w.episode ?: -1) } }))
        o.put("savedMovies", JSONArray(st.savedMovieIds.toList()))
        o.put("savedPosts", JSONArray(st.savedPostIds.toList()))
        o.put("following", JSONArray(st.followingIds.toList()))
        o.put("privacy", JSONObject(st.privacy))
        o.put("posts", JSONArray(st.posts.map { p -> JSONObject().apply { put("id",p.id);put("authorId",p.authorId);put("content",p.content);put("time",p.time);put("kind",p.kind);put("likes",p.likes);put("comments",p.comments);put("reposts",p.reposts) } }))
        prefs.edit().putString("state",o.toString()).apply()
    }

    private fun loadState():AppState {
        val base=seedState(); val raw=prefs.getString("state",null) ?: return base
        return try {
            val o=JSONObject(raw)
            val watch=mutableListOf<WatchEntry>(); val wa=o.optJSONArray("watch")
            if(wa!=null) for(i in 0 until wa.length()){val x=wa.getJSONObject(i);watch+=WatchEntry(x.getString("id"),x.getString("movieId"),x.getString("date"),x.getString("review"),x.getString("opinion"),x.optInt("season",-1).takeIf{it>=0},x.optInt("episode",-1).takeIf{it>=0})}
            val posts=mutableListOf<Post>(); val pa=o.optJSONArray("posts")
            if(pa!=null) for(i in 0 until pa.length()){val x=pa.getJSONObject(i);posts+=Post(x.getString("id"),x.getString("authorId"),x.getString("content"),x.getString("time"),x.optString("kind","post"),likes=x.optInt("likes"),comments=x.optInt("comments"),reposts=x.optInt("reposts"))}
            fun set(key:String)=buildSet<String>{val a=o.optJSONArray(key);if(a!=null)for(i in 0 until a.length())add(a.getString(i))}
            val priv=buildMap<String,Boolean>{val po=o.optJSONObject("privacy");if(po!=null)for(k in po.keys())put(k,po.optBoolean(k,true))}
            base.copy(watchEntries=watch.ifEmpty{base.watchEntries},posts=posts.ifEmpty{base.posts},savedMovieIds=set("savedMovies").ifEmpty{base.savedMovieIds},savedPostIds=set("savedPosts").ifEmpty{base.savedPostIds},followingIds=set("following").ifEmpty{base.followingIds},privacy=if(priv.isEmpty())base.privacy else priv)
        } catch(_:Exception){base}
    }

    private fun seedState():AppState = AppState(
        currentUser=User("u1","Patricia Jasury","@patriciaj",followers=128,following=96,moviesSeen=42),
        users=listOf(User("u1","Patricia Jasury","@patriciaj",followers=128,following=96,moviesSeen=42),User("u2","Luna Story","@lunastory",followers=842,following=214,moviesSeen=180),User("u3","Cinema Lover","@cinemalover",followers=421,following=302,moviesSeen=97,isPrivate=true),User("u4","Tinker Fan","@tinkerfan",followers=210,following=120,moviesSeen=76)),
        movies=listOf(
            Movie("m1","Enredados",2010,"Nathan Greno & Byron Howard","Animación","1h 40m","Una princesa perdida descubre un mundo fuera de su torre y cambia su historia para siempre.",4.9,""),
            Movie("m2","Tinker Bell",2008,"Bradley Raymond","Animación","1h 18m","Una hada curiosa descubre su talento y el valor de creer en sí misma.",4.8,""),
            Movie("m3","Titanic",1997,"James Cameron","Romance / Drama","3h 14m","Una historia de amor ambientada en el viaje del Titanic.",4.7,""),
            Movie("m4","The Little Mermaid",2023,"Rob Marshall","Fantasía","2h 15m","Una joven sirena sueña con conocer el mundo humano.",4.4,""),
            Movie("m5","Inside Out 2",2024,"Kelsey Mann","Animación","1h 40m","Nuevas emociones aparecen mientras Riley crece.",4.6,""),
            Movie("m6","Wednesday",2022,"Tim Burton","Comedia / Misterio","T1","Una estudiante investiga misterios en una academia peculiar.",4.5,"",type="series")
        ),
        watchEntries=listOf(WatchEntry("w1","m1","2026-10-02","Me encantó la aventura.","Una de mis favoritas."),WatchEntry("w2","m2","2026-10-03","Tierna y divertida.","Perfecta para volver a verla."),WatchEntry("w3","m3","2026-10-04","Gran historia.","Clásico.")),
        posts=listOf(Post("p1","u2","Hoy volví a ver una película que amo. 🎬","Hace 2 h",likes=31,comments=4,reposts=2),Post("p2","u4","Tinker Bell siempre tiene un lugar especial. 🧚","Ayer",likes=18,comments=2)),
        stories=listOf(Story("s1","u2","Nueva historia sobre mi maratón ✨","Hace 1 h"),Story("s2","u4","Mi recomendación de hoy 🧚","Hace 3 h")),
        groups=listOf(Group("g1","Tinker Bell Fans","Todo sobre Tinker Bell y sus películas.",false,true,"u4",234,"Tinker Bell"),Group("g2","Animación Disney","Conversaciones sobre animación Disney.",true,false,"u2",89,"Animación")),
        savedMovieIds=setOf("m5","m6"),savedPostIds=setOf("p1"),
        notifications=listOf(NotificationItem("n1","Luna Story publicó una nota.","Hoy"),NotificationItem("n2","Tinker Fan empezó a seguirte.","Hoy"),NotificationItem("n3","Tienes un título guardado pendiente.","Esta semana")),
        followingIds=setOf("u2","u4"),
        privacy=mapOf("joinDate" to true,"birthday" to false,"likes" to true,"links" to false,"contact" to false,"interests" to true,"personal" to false,"posts" to true,"photos" to true,"stats" to true)
    )
}
