package com.myfavoritestory.app.data

data class User(val id:String,val name:String,val username:String,val avatar:String="",val followers:Int=0,val following:Int=0,val moviesSeen:Int=0,val isPrivate:Boolean=false,val activity:Boolean=true)
data class Movie(val id:String,val title:String,val year:Int,val director:String,val genre:String,val duration:String,val synopsis:String,val rating:Double,val poster:String,val type:String="movie")
data class WatchEntry(val id:String,val movieId:String,val date:String,val review:String,val opinion:String,val season:Int?=null,val episode:Int?=null,val personalPhoto:String?=null,val photoPublic:Boolean=true)
data class Post(val id:String,val authorId:String,val content:String,val time:String,val kind:String="post",val image:String?=null,val likes:Int=0,val comments:Int=0,val reposts:Int=0,val saved:Boolean=false)
data class Story(val id:String,val authorId:String,val text:String,val time:String,val reactions:Int=0)
data class Group(val id:String,val name:String,val description:String,val isPrivate:Boolean,val showCreator:Boolean,val creatorId:String,val members:Int,val topic:String)
data class NotificationItem(val id:String,val text:String,val category:String,val unread:Boolean=true)

data class AppState(
    val currentUser:User,
    val users:List<User>,
    val movies:List<Movie>,
    val watchEntries:List<WatchEntry>,
    val posts:List<Post>,
    val stories:List<Story>,
    val groups:List<Group>,
    val savedMovieIds:Set<String>,
    val savedPostIds:Set<String>,
    val notifications:List<NotificationItem>,
    val followingIds:Set<String>,
    val privacy:Map<String,Boolean>
)
