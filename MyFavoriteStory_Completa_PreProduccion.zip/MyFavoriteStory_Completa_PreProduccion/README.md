# My Favorite Story — Completa Preproducción

Proyecto Android nativo en Kotlin + Jetpack Compose, preparado para abrirse en Android Studio.

## Qué incluye

- Navegación superior e inferior.
- Calendario mensual con celdas de tamaño fijo.
- Registro local de películas/series con reseña, opinión, fecha y soporte T/C.
- Detalle de día.
- Sección **Para ver** con Películas/Series, Tendencias, Nuevo, Próximamente y Favoritos.
- Búsqueda de personas y títulos.
- Perfil propio y perfil de otras personas.
- Seguidores, siguiendo y amigos con búsqueda e indicador de actividad.
- Publicaciones, notas, historias y recomendaciones en modo local.
- Comentarios/likes/reposts/guardado representados en UI de preproducción.
- Notificaciones locales y estado de no leídas.
- Grupos públicos/privados y pantallas de administración preparadas.
- Guardado y publicaciones guardadas.
- Pantallas de cuentas, creación de cuenta, configuración y privacidad.
- Datos de prueba incluidos.
- Interfaces `AuthProvider`, `BackendRepository` y `StorageProvider` para conectar servicios reales posteriormente.

## Abrir

1. Instala Android Studio actualizado.
2. Selecciona **Open** y abre la carpeta `MyFavoriteStory_Completa_PreProduccion`.
3. Deja que Gradle descargue las dependencias.
4. Usa un teléfono Android o emulador con Android 7.0 (API 24) o superior.
5. Ejecuta el módulo `app`.

## Probar en teléfono Android

### Opción A — USB
1. Activa Opciones de desarrollador en Android.
2. Activa Depuración USB.
3. Conecta el teléfono al PC.
4. Acepta la autorización RSA en el teléfono.
5. En Android Studio selecciona el teléfono y pulsa Run.

### Opción B — APK de prueba
Después de sincronizar el proyecto en Android Studio, usa **Build → Build APK(s)** (o **Build → Generate App Bundles or APKs → Generate APKs**).

El APK quedará normalmente en:

`app/build/outputs/apk/debug/app-debug.apk`

Puedes transferirlo al teléfono e instalarlo para probar la versión local.

## Backend pendiente

No se ha fingido una conexión online. La aplicación usa datos locales/mock mientras no exista backend.

### Base de datos futura
Se recomienda crear colecciones/tablas para:

- users, profiles
- movies, series, seasons, episodes
- watch_entries
- posts, stories, notes, recommendations
- comments, comment_replies, likes, reposts, shares
- followers, friendships
- groups, group_members, group_requests
- notifications
- privacy_settings

### Storage futuro
Conectar almacenamiento para:

- fotos de perfil
- portadas
- fotos del calendario
- imágenes de publicaciones
- historias
- fotos de grupos

### Auth futuro
Conectar:

- Google OAuth
- teléfono/SMS
- email + contraseña

Las interfaces preparadas están en `data/LocalRepository.kt`.

## Nota de preproducción

Esta entrega es una base funcional amplia para pruebas de UX y flujo. Las imágenes reales, sincronización entre dispositivos, autenticación real, moderación de servidor, notificaciones push y reglas de seguridad todavía deben conectarse antes de producción.
